/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;


import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.BookFacadeLocal;
import za.ac.tut.entities.Author;
import za.ac.tut.entities.Book;

/**
 *
 * @author Sandiso
 */
public class AddbookServlet extends HttpServlet {

    @EJB private BookFacadeLocal bfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            Integer isbn = Integer.parseInt(request.getParameter("isbn"));
            String title = request.getParameter("title");
            double price = Double.parseDouble(request.getParameter("price"));
            String pd = request.getParameter("pd");
            SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-mm-dd");
            Date pubdate = dateformat.parse(pd);
            String authorName = request.getParameter("authorName");
            String authorSurname = request.getParameter("authorSurname");
            
            Book book = createBook(isbn,title,price,pubdate,authorName,authorSurname);
            bfl.create(book);
            
            RequestDispatcher disp = request.getRequestDispatcher("Add_Book_outcome.jsp");
            disp.forward(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(AddbookServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    private Book createBook(Integer isbn, String title, double price, Date pubdate, String authorName, String authorSurname) {
       
       Author a = new Author( authorName,authorSurname);
       Book b = new Book(isbn, title, pubdate, price, a, pubdate);
       
       return b;
    }

}
