<%-- 
    Document   : Add_Book_outcome
    Created on : 23 Apr 2025, 11:26:11 PM
    Author     : Sandiso
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Add Book Outcome Page</title>
    </head>
    <body>
        <h1>Add Book Outcome</h1>
        
        <p>
            The book has been Added successfully.
            Please click <a href="menu.jsp">here</a> to get back to the menu page or <a href="index.html">here</a> to the main page
        </p>
        
    </body>
</html>
