<%-- 
    Document   : menu
    Created on : 23 Apr 2025, 10:46:09 PM
    Author     : Sandiso
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Menu Page</title>
    </head>
    <body>
        <h1>Menu Page</h1>
        <p>
            Please select one of the following options:
        </p>
        
        <ul>
            <li><a href="add_book.jsp">Add a book</a></li>
            <li><a href="get_books.jsp">Get all books</a></li>
        </ul>
        
    </body>
</html>
