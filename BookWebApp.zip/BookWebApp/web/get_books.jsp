<%-- 
    Document   : get_books
    Created on : 23 Apr 2025, 10:59:28 PM
    Author     : Sandiso
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Get books Page</title>
    </head>
    <body>
        <h1>Get books</h1>
        
        <p>
            Please click on th e button below to get the books.
        </p>
        
        <form action="GetbooksServlet.do" method="GET">
            <table>
                <tr>
                    <td></td>
                    <td><input type="submit" value="GET BOOKS"/></td>
                </tr>
            </table>
        </form>
    </body>
</html>
