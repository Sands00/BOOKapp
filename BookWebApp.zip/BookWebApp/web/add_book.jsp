<%-- 
    Document   : add_book
    Created on : 23 Apr 2025, 10:51:22 PM
    Author     : Sandiso
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Add book Page</title>
    </head>
    <body>
        <h1>Add book</h1>
        <p>
            Please add book details below:
        </p>
        <form action="AddbookServlet.do" method="POST">
            <table border="1">
                <tbody>
                    <tr>
                        <td>ISBN:</td>
                        <td><input type="text" name="isbn"/></td>
                    </tr>
                    <tr>
                        <td>Title:</td>
                       <td><input type="text" name="title"/></td>
                    </tr>
                    <tr>
                        <td>Price:</td>
                        <td><input type="text" name="price"/></td>
                    </tr>
                    <tr>
                        <td>Publication date:</td>
                        <td><input type="date" name="pd"/></td>
                    </tr>
                    <tr>
                        <td>Author name:</td>
                        <td><input type="text" name="authorName"/></td>
                    </tr>
                    <tr>
                        <td>Author surname:</td>
                        <td><input type="text" name="authorSurname"/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="ADD BOOK"/></td>
                    </tr>
                    
                </tbody>
            </table>

        </form>
    </body>
</html>
