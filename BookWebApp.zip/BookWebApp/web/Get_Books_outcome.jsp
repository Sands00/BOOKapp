<%-- 
    Document   : Get_Books_outcome
    Created on : 23 Apr 2025, 11:29:08 PM
    Author     : Sandiso
--%>

<%@page import="java.util.Date"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.List"%>
<%@page import="za.ac.tut.entities.Book"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Get Books Outcome Page</title>
    </head>
    <body>
        <h1>Get Books Outcome</h1>
        <%
            List<Book> books = (List<Book>) request.getAttribute("books");
        %>
        
        <p>
            Below are the books retrieved from the database.
        </p>
        
        <table border="1">
            
            <thead>
                    <tr>
                        <th>ISBN:</th>
                        <th>TiTle:</th>
                        <th>Author Name:</th>
                        <th>Author Surname:</th>
                        <th>Price:</th>
                        <th>Publication date:</th>
                    </tr>
                </thead>
                
            <%
                for(int i=0;i<books.size();i++){
                    Book b = books.get(i);
                    int isbn = b.getId();
                    String title = b.getTitle();
                    String name = b.getAuthor().getName();
                    String surname = b.getAuthor().getSurname();
                    Double price = b.getPrice();
                    SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");
                    Date pd = b.getPublicationdate();
                    String date = dtf.format(pd);
                    
            
            %>
            
            
                
                <tbody>
                    <tr>
                    <td><%=isbn%></td>
                    <td><%=title%></td>
                    <td><%=name%></td>
                    <td><%=surname%></td>
                    <td><%=price%></td>
                    <td><%=date%></td>
                </tr>
                <%}%>
                    
                </tbody>
            </table>

                
                
            </tbody>
        </table>

    </body>
</html>
